package co.edu.utp.misiontic2022.c2;

public class App {
    public static void main(String[] args) {
        // Declaración e inicialización del arreglo "arr" con tamaño 5
        int arr[] = new int[5];

        arr[0] = 3;
        arr[1] = 8;
        arr[2] = 9;
        arr[3] = 8;
        arr[4] = 3;
        arr[5] = 8;

        for (int i = 0; i < arr.length; i++) {
            System.out.println(arr[i]);
        }

    }
}
