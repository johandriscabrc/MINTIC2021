public class App {
    public static void main(String[] args) throws Exception {
        CompraFlota objFlota = new CompraFlota();

        System.out.println(objFlota.compararCompra(12, 1000, 0));
    }
}
