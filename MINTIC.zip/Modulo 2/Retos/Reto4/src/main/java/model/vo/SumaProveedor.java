package model.vo;

public class SumaProveedor {
    private String cantidad;

    public SumaProveedor() {
    }

    public SumaProveedor(String cantidad) {
        this.cantidad = cantidad;
    }

    public String getCantidad() {
        return cantidad;
    }

    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }

}
