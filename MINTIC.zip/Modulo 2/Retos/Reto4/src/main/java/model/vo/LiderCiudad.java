package model.vo;

public class LiderCiudad {
    private String NombreLíder;

    public LiderCiudad() {

    }

    public LiderCiudad(String NombreLíder) {
        this.NombreLíder = NombreLíder;
    }

    public String getNombreLíder() {
        return NombreLíder;
    }

    public void setNombreLíder(String NombreLíder) {
        this.NombreLíder = NombreLíder;
    }

}
