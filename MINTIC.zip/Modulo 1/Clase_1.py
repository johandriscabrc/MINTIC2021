'''
PRIMER EJERCICIO
print("El lado del cuadrado es: ")
lado=int(input())
rlado=lado*lado
print("El parametro del cuadrado es: ")
parametro=int(input())
rparametro=parametro*4
print("Resultado lado del cuadrado es: " + str(rlado))
print("Resultado parametro del cuadrado es: " + str(rparametro))

SEGUNDO EJERCICIO
def calcular(lado):
    area=lado*lado
    parametro=lado+lado+lado+lado
    print("Resultado del area cuadrado es: " + str(area))
    print("Resultado del parametro es: " + str(parametro))
calcular(38)
'''
