numero = input("Digite un número: ")

if numero[:1] == "4":
    print("Este número termina de 4")
else:
    print("Este número NO termina en 4")

